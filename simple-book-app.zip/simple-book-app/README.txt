
📘 Simple Book App

Run Instructions:

1️⃣ Start Backend
------------------
cd backend
npm install
node index.js

Runs on: http://localhost:5000/books

2️⃣ Start Frontend
-------------------
cd frontend
npm install
npm start

Runs on: http://localhost:3000
